#!/bin/bash
dbt run --profiles-dir .
